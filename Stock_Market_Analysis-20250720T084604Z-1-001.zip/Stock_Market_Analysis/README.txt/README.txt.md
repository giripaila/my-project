Stock Market Trends Analysis
-----------------------------

Student Name: Narasimha Paila
Project: Internship – Data Analytics with Python
Topic: Stock Market Trends Analysis using Python

Description:
This project analyzes historical stock prices of Apple Inc. (AAPL) using yfinance and Python data analysis tools.

Folders:
- Dataset: Contains the downloaded stock CSV file.
- Source_Code: Contains the main Jupyter Notebook (.ipynb).
- Output/Graphs: Graphs generated from the analysis.
- Final_Report: A summary report in PDF format.

Key Insights:
- Closing price trend shows growth over time.
- Moving average smooths market noise.
- Daily returns show volatility for trading risk.

Tools Used:
Python, Google Colab, yfinance, matplotlib, pandas, seaborn
